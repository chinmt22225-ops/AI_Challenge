import time
import numpy as np
from collections import deque

# ==========================================
# 1. CONFIGURATION
# ==========================================
class Config:
    TIME_LIMIT_MS = 90           # Dừng tìm kiếm khi quá giới hạn để chừa thời gian cho I/O (luật là 100ms)
    MAX_DEPTH = 6                # Độ sâu tối đa cho Iterative Deepening
    
    # Trọng số lượng giá
    SCORE_DEATH = -10000000.0    # Chết
    SCORE_SURVIVE = 10000.0      # Sống sót
    SCORE_IN_DANGER = -5000.0    # Điểm phạt khi đứng vào vùng nguy hiểm (vùng bom sẽ nổ)
    SCORE_PICKUP_ITEM = 500.0    # Điểm thưởng nhặt vật phẩm
    SCORE_BOMB_BREAK_BOX = 100.0 # Điểm thưởng khi đặt bom phá hộp
    WEIGHT_DISTANCE_ITEM = 20.0  # Điểm tiếp cận mục tiêu vật phẩm
    WEIGHT_DISTANCE_ENEMY = 5.0  # Điểm tiếp cận kẻ địch
    MAX_DISTANCE_REWARD = 20.0   # Khoảng cách tối đa để cộng điểm


# ==========================================
# 2. STATE & ENVIRONMENT SIMULATION
# ==========================================
# Theo engine chuẩn: 0: IDLE, 1: UP, 2: DOWN, 3: LEFT, 4: RIGHT, 5: BOMB
ACTION_IDLE = 0
ACTION_UP = 1
ACTION_DOWN = 2
ACTION_LEFT = 3
ACTION_RIGHT = 4
ACTION_BOMB = 5

class GameState:
    def __init__(self, grid, players, bombs, my_agent_id):
        self.grid = np.copy(grid)
        self.players = [list(p) for p in players] 
        self.bombs = [list(b) for b in bombs]
        self.my_agent_id = my_agent_id
        
    def clone(self):
        return GameState(self.grid, self.players, self.bombs, self.my_agent_id)
        
    def _in_bounds(self, x, y):
        return 0 <= x < self.grid.shape[0] and 0 <= y < self.grid.shape[1]
        
    def _is_passable(self, x, y):
        if not self._in_bounds(x, y):
            return False
        return self.grid[x, y] in [0, 3, 4]

    def _get_danger_zones(self):
        danger_tiles = set()
        for b in self.bombs:
            bx, by, timer = int(b[0]), int(b[1]), int(b[2])
            owner_id = int(b[3]) if len(b) > 3 else -1
            radius = 2 # default
            if 0 <= owner_id < len(self.players):
                radius = max(1, int(self.players[owner_id][4]) + 1)
                
            danger_tiles.add((bx, by))
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                for r in range(1, radius + 1):
                    nx, ny = bx + dx*r, by + dy*r
                    if not self._in_bounds(nx, ny):
                        break
                    cell = self.grid[nx, ny]
                    if cell == 1: # Wall
                        break
                    danger_tiles.add((nx, ny))
                    if cell == 2: # Box blocks explosion but is destroyed
                        break
        return danger_tiles

    def get_legal_actions(self, agent_id):
        if agent_id >= len(self.players) or self.players[agent_id][2] != 1:
            return [ACTION_IDLE]
            
        p = self.players[agent_id]
        px, py = int(p[0]), int(p[1])
        bombs_left = int(p[3])
        
        occupied = {(int(op[0]), int(op[1])) for i, op in enumerate(self.players) if i != agent_id and op[2] == 1}
        bomb_pos = {(int(b[0]), int(b[1])) for b in self.bombs}
        
        actions = [ACTION_IDLE]
        
        VALID_DIRS = {
            ACTION_UP: (-1, 0), ACTION_DOWN: (1, 0), 
            ACTION_LEFT: (0, -1), ACTION_RIGHT: (0, 1)
        }
        for a, (dx, dy) in VALID_DIRS.items():
            nx, ny = px + dx, py + dy
            if self._is_passable(nx, ny) and (nx, ny) not in occupied:
                actions.append(a)
                
        if bombs_left > 0 and (px, py) not in bomb_pos:
            actions.append(ACTION_BOMB)
            
        return actions

    def generate_successor(self, agent_id, action):
        new_state = self.clone()
        if agent_id >= len(new_state.players) or new_state.players[agent_id][2] != 1:
            return new_state
            
        p = new_state.players[agent_id]
        px, py = int(p[0]), int(p[1])
        
        DIR_MAP = {1: (-1, 0), 2: (1, 0), 3: (0, -1), 4: (0, 1), 0: (0, 0)}
        
        if action in DIR_MAP:
            dx, dy = DIR_MAP[action]
            nx, ny = px + dx, py + dy
            p[0], p[1] = nx, ny
            
            if new_state.grid[nx, ny] == 3:
                p[4] += 1
                new_state.grid[nx, ny] = 0
            elif new_state.grid[nx, ny] == 4:
                p[3] += 1 
                new_state.grid[nx, ny] = 0
                
        elif action == ACTION_BOMB:
            p[3] -= 1
            new_state.bombs.append([px, py, 7, agent_id])
            
        # Tick bombs
        explosions = []
        surviving_bombs = []
        for b in new_state.bombs:
            b[2] -= 1
            if b[2] <= 0:
                explosions.append(b)
            else:
                surviving_bombs.append(b)
        new_state.bombs = surviving_bombs
        
        blast_zones = set()
        broken_boxes = set()
        for b in explosions:
            bx, by, _, owner_id = b
            radius = 2
            if 0 <= owner_id < len(new_state.players):
                radius = max(1, int(new_state.players[owner_id][4]) + 1)
                if owner_id == agent_id:
                    new_state.players[agent_id][3] += 1 
                    
            blast_zones.add((bx, by))
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                for r in range(1, radius + 1):
                    nx, ny = bx + dx*r, by + dy*r
                    if not new_state._in_bounds(nx, ny): break
                    if new_state.grid[nx, ny] == 1: break
                    blast_zones.add((nx, ny))
                    if new_state.grid[nx, ny] == 2:
                        broken_boxes.add((nx, ny))
                        break
                        
        for (bx, by) in broken_boxes:
            new_state.grid[bx, by] = 0
            
        for i, player in enumerate(new_state.players):
            if player[2] == 1 and (int(player[0]), int(player[1])) in blast_zones:
                player[2] = 0
                
        return new_state

    def is_terminal(self):
        p = self.players[self.my_agent_id]
        return p[2] == 0


# ==========================================
# 3. EVALUATOR & BFS HEURISTICS
# ==========================================
class Evaluator:
    @staticmethod
    def evaluate(state, agent_id):
        if agent_id >= len(state.players):
            return Config.SCORE_DEATH
            
        me = state.players[agent_id]
        if me[2] == 0:
            return Config.SCORE_DEATH
            
        score = Config.SCORE_SURVIVE
        my_pos = (int(me[0]), int(me[1]))
        danger_tiles = state._get_danger_zones()
        
        if my_pos in danger_tiles:
            score += Config.SCORE_IN_DANGER
            
        items, enemies, boxes = Evaluator._bfs_distances(state, my_pos, danger_tiles)
        
        if items:
            nearest_item_dist = min(items)
            if nearest_item_dist < Config.MAX_DISTANCE_REWARD:
                score += Config.WEIGHT_DISTANCE_ITEM * (Config.MAX_DISTANCE_REWARD - nearest_item_dist)
                
        if enemies:
            nearest_enemy_dist = min(enemies)
            if nearest_enemy_dist < Config.MAX_DISTANCE_REWARD:
                score += Config.WEIGHT_DISTANCE_ENEMY * (Config.MAX_DISTANCE_REWARD - nearest_enemy_dist)
                
        if boxes:
            nearest_box_dist = min(boxes)
            if nearest_box_dist == 1:
                score += Config.SCORE_BOMB_BREAK_BOX * 0.5 
                
        return score

    @staticmethod
    def _bfs_distances(state, start_pos, danger_tiles):
        q = deque([(start_pos, 0)])
        seen = {start_pos}
        item_dists = []
        enemy_dists = []
        box_dists = []
        
        enemy_positions = {(int(p[0]), int(p[1])) for i, p in enumerate(state.players) if i != state.my_agent_id and p[2] == 1}
        bomb_pos = {(int(b[0]), int(b[1])) for b in state.bombs}
        
        while q:
            pos, dist = q.popleft()
            x, y = pos
            if state.grid[x, y] in [3, 4]:
                item_dists.append(dist)
                
            if pos in enemy_positions:
                enemy_dists.append(dist)
                
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = x + dx, y + dy
                if state._in_bounds(nx, ny) and state.grid[nx, ny] == 2:
                    box_dists.append(dist + 1)
            
            if dist > Config.MAX_DISTANCE_REWARD:
                continue
                
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nx, ny = x + dx, y + dy
                npos = (nx, ny)
                if npos in seen: continue
                if not state._is_passable(nx, ny): continue
                if npos in bomb_pos: continue
                if npos in danger_tiles: continue
                    
                seen.add(npos)
                q.append((npos, dist + 1))
                
        return item_dists, enemy_dists, box_dists

    @staticmethod
    def evaluate_action_heuristic(state, action):
        reward = 0
        me = state.players[state.my_agent_id]
        px, py = int(me[0]), int(me[1])
        radius = max(1, int(me[4]) + 1)
        
        if action == 5: # BOMB
            boxes_hit = 0
            for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                for r in range(1, radius + 1):
                    nx, ny = px + dx*r, py + dy*r
                    if not state._in_bounds(nx, ny): break
                    if state.grid[nx, ny] == 1: break
                    if state.grid[nx, ny] == 2:
                        boxes_hit += 1
                        break
            if boxes_hit > 0:
                reward += Config.SCORE_BOMB_BREAK_BOX * boxes_hit
                
        return reward


# ==========================================
# 4. AGENT LOGIC (ALPHA-BETA SEARCH)
# ==========================================
class Agent:
    team_id = "AlphaBetaAgent"
    
    def __init__(self, agent_id):
        self.agent_id = int(agent_id)
        
    def act(self, obs):
        start_time = time.time()
        grid = obs["map"]
        players = obs["players"]
        bombs = obs["bombs"]
        
        state = GameState(grid, players, bombs, self.agent_id)
        
        best_action = 0
        legal_actions = state.get_legal_actions(self.agent_id)
        
        if not legal_actions:
            return 0
        if len(legal_actions) == 1:
            return legal_actions[0]
            
        if 5 in legal_actions:
            legal_actions.remove(5)
            legal_actions.insert(0, 5)
        
        for depth in range(1, Config.MAX_DEPTH + 1):
            alpha = float('-inf')
            beta = float('inf')
            current_best_action = legal_actions[0]
            current_max_eval = float('-inf')
            search_interrupted = False
            
            for action in legal_actions:
                elapsed_ms = (time.time() - start_time) * 1000
                if elapsed_ms > Config.TIME_LIMIT_MS:
                    search_interrupted = True
                    break
                    
                successor = state.generate_successor(self.agent_id, action)
                action_reward = Evaluator.evaluate_action_heuristic(state, action)
                
                eval_val = action_reward + self.alpha_beta(successor, depth - 1, alpha, beta, False, start_time)
                
                if eval_val > current_max_eval:
                    current_max_eval = eval_val
                    current_best_action = action
                    
                alpha = max(alpha, eval_val)
                
            if not search_interrupted or depth == 1:
                best_action = current_best_action
            
            if search_interrupted:
                break
                
        return best_action

    def alpha_beta(self, state, depth, alpha, beta, maximizing_player, start_time):
        if depth == 0 or state.is_terminal():
            return Evaluator.evaluate(state, self.agent_id)
            
        elapsed_ms = (time.time() - start_time) * 1000
        if elapsed_ms > Config.TIME_LIMIT_MS:
            return Evaluator.evaluate(state, self.agent_id)

        if maximizing_player:
            max_eval = float('-inf')
            legal_actions = state.get_legal_actions(self.agent_id)
            if not legal_actions:
                return Evaluator.evaluate(state, self.agent_id)
                
            for action in legal_actions:
                successor = state.generate_successor(self.agent_id, action)
                action_reward = Evaluator.evaluate_action_heuristic(state, action)
                eval_val = action_reward + self.alpha_beta(successor, depth - 1, alpha, beta, False, start_time)
                max_eval = max(max_eval, eval_val)
                alpha = max(alpha, eval_val)
                if beta <= alpha:
                    break
            return max_eval
        else:
            min_eval = float('inf')
            successor = state.generate_successor(self.agent_id, 0) 
            
            eval_val = self.alpha_beta(successor, depth - 1, alpha, beta, True, start_time)
            min_eval = min(min_eval, eval_val)
            beta = min(beta, eval_val)
            
            return min_eval
