# ============================================================
# Bomberland GDGoC AI Challenge 2026
# Training Script: Imitation Learning → PPO Fine-tuning
# KHÔNG NỘPFILE NÀY — chỉ dùng để train trên Kaggle/local
#
# Usage:
#   python train.py --phase il_collect --episodes 5000 --output demos.pkl
#   python train.py --phase il_train   --demos demos.pkl --output weights_il.pth
#   python train.py --phase ppo        --load weights_il.pth --output weights_final.pth
#   python train.py --phase benchmark  --load weights_final.pth --episodes 100
# ============================================================

import sys
import os
import time
import random
import pickle
import argparse
import math
from pathlib import Path
from collections import deque
from copy import deepcopy

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

# Import từ agent.py (phải cùng thư mục)
sys.path.insert(0, str(Path(__file__).parent))
from agent import (
    GameState, ActorCriticNet, AlphaBetaMasker, encode_obs,
    ACTION_STOP, ACTION_UP, ACTION_DOWN, ACTION_LEFT, ACTION_RIGHT, ACTION_BOMB,
    DIR_MAP, GRASS, WALL, BOX, ITEM_RAD, ITEM_CAP,
    BOMB_TIMER, MAX_RADIUS, MAX_CAPACITY, GRID_SIZE,
)


# ============================================================
# SECTION A: DATA CLASSES (PlayerData, BombData)
# ============================================================

class PlayerData:
    """Đại diện cho 1 agent trong GameEnv."""

    def __init__(self, pid: int, row: int, col: int):
        self.id   = pid
        self.x    = row
        self.y    = col
        self.alive = True

        # Bomb stats
        self.bombs_left        = 1   # Số bom có thể đặt ngay
        self.bomb_radius_bonus = 0   # radius thực = 1 + bonus; max bonus = 4
        self.max_capacity      = 1   # capacity tối đa (tăng khi nhặt ITEM_CAP)

        # Stats for tiebreaker & reward tracking
        self.kills          = 0
        self.boxes_broken   = 0
        self.items_collected = 0
        self.bombs_placed   = 0

    def to_obs_array(self) -> list:
        """Chuyển sang format obs['players'][i] = [x, y, alive, bombs_left, radius_bonus]."""
        return [self.x, self.y, int(self.alive), self.bombs_left, self.bomb_radius_bonus]

    @property
    def radius(self) -> int:
        return 1 + self.bomb_radius_bonus


class BombData:
    """Đại diện cho 1 quả bom trên bản đồ."""

    def __init__(self, x: int, y: int, owner_id: int, radius: int, timer: int = BOMB_TIMER):
        self.x        = x
        self.y        = y
        self.owner_id = owner_id
        self.radius   = radius
        self.timer    = timer

    def to_obs_array(self) -> list:
        """Format obs['bombs'][i] = [x, y, timer, owner_id]."""
        return [self.x, self.y, self.timer, self.owner_id]


# ============================================================
# SECTION B: GAME ENVIRONMENT (Full 4-agent simulation)
# ============================================================

class GameEnv:
    """
    Mô phỏng đầy đủ engine Bomberland cho 4 agents.
    Độ trung thực ≥ 95% với engine BTC.

    Resolution order (đúng theo BTC game.py):
      1. Collect Actions
      2. Process Movement (đồng thời — item contention tại đây)
      3. Place Bombs (conflict resolution theo radius và ID)
      4. Decrease Bomb Timers
      5. Resolve Explosions (bao gồm chain reaction)
      6. Remove dead agents (sau khi tất cả bom đã nổ)
      7. Spawn Items (auto-spawn theo xác suất step-based)
      8. Check End Conditions
    """

    # Vị trí xuất phát cố định theo engine BTC
    STARTING_POSITIONS = [
        (1, 1),    # Agent 0: top-left
        (11, 11),  # Agent 1: bottom-right
        (1, 11),   # Agent 2: top-right
        (11, 1),   # Agent 3: bottom-left
    ]

    def __init__(self, seed: int = None):
        self.rng = np.random.default_rng(seed)
        self.grid    = None
        self.players = []
        self.bombs   = []
        self.current_step = 0
        self.reset(seed=seed)

    def reset(self, seed: int = None) -> dict:
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self.current_step = 0
        self.grid    = self._generate_map()
        self.players = [
            PlayerData(i, r, c)
            for i, (r, c) in enumerate(self.STARTING_POSITIONS)
        ]
        self.bombs = []
        return self._get_obs()

    # ── Map generation ────────────────────────────────────────────────

    def _generate_map(self) -> np.ndarray:
        """
        Tạo bản đồ 13×13 ngẫu nhiên:
          - Border walls (hàng/cột 0 và 12)
          - Checkerboard walls tại (row chẵn, col chẵn) trong vùng play (1-11)
          - Vùng 2×2 quanh 4 góc luôn là GRASS (safe zone)
          - Phần còn lại: 30% BOX, 5% WALL thêm, 65% GRASS
        """
        grid = np.zeros((GRID_SIZE, GRID_SIZE), dtype=np.int8)

        # Border walls cố định
        grid[0, :]  = WALL
        grid[-1, :] = WALL
        grid[:, 0]  = WALL
        grid[:, -1] = WALL

        # Checkerboard walls (tường cố định trong engine BTC)
        for r in range(2, 12, 2):   # row chẵn: 2,4,6,8,10
            for c in range(2, 12, 2):  # col chẵn: 2,4,6,8,10
                grid[r, c] = WALL

        # Safe zones quanh 4 góc (đảm bảo agent không bị kẹt ngay đầu)
        safe = set()
        for sr, sc in self.STARTING_POSITIONS:
            for dr in range(-1, 2):
                for dc in range(-1, 2):
                    rr, cc = sr + dr, sc + dc
                    if 1 <= rr <= 11 and 1 <= cc <= 11:
                        safe.add((rr, cc))

        # Random fill các ô còn lại
        for r in range(1, 12):
            for c in range(1, 12):
                if grid[r, c] == WALL:
                    continue
                if (r, c) in safe:
                    continue
                roll = self.rng.random()
                if roll < 0.30:
                    grid[r, c] = BOX
                elif roll < 0.35:
                    grid[r, c] = WALL

        return grid

    # ── Observation ───────────────────────────────────────────────────

    def _get_obs(self) -> dict:
        """Trả về observation theo format engine BTC (full observability)."""
        players_arr = np.array(
            [p.to_obs_array() for p in self.players], dtype=np.int8
        )
        bombs_arr = (
            np.array([b.to_obs_array() for b in self.bombs], dtype=np.int8)
            if self.bombs
            else np.zeros((0, 4), dtype=np.int8)
        )
        return {
            "map":     self.grid.copy(),
            "players": players_arr,
            "bombs":   bombs_arr,
        }

    # ── Main step function ────────────────────────────────────────────

    def step(self, actions: list) -> tuple:
        """
        Thực hiện 1 game step với actions của 4 agents.

        Args:
            actions: list[int] len=4, actions[i] là action của agent i

        Returns:
            obs:     dict — observation sau step
            rewards: list[float] len=4 — reward cho mỗi agent step này
            done:    bool — game kết thúc?
            info:    dict — thống kê step (kills, boxes, items, ...)
        """
        self.current_step += 1
        rewards = [0.0] * 4
        info = {
            "kills":          [0] * 4,
            "boxes_broken":   [0] * 4,
            "items_got":      [0] * 4,
            "item_contention":[0] * 4,
            "bombs_placed":   [0] * 4,
            "dead_this_step": [],
        }

        # ── Bước 2: Process Movement (đồng thời) ──────────────────────
        bomb_positions_before = {(b.x, b.y) for b in self.bombs}
        new_positions = {}   # agent_id → (new_x, new_y)

        for i, player in enumerate(self.players):
            if not player.alive:
                new_positions[i] = (player.x, player.y)
                continue

            action = int(actions[i])
            if action in DIR_MAP and action != ACTION_STOP:
                dx, dy = DIR_MAP[action]
                nx, ny = player.x + dx, player.y + dy
                if self._can_move_to(nx, ny, bomb_positions_before):
                    new_positions[i] = (nx, ny)
                else:
                    new_positions[i] = (player.x, player.y)
            else:
                new_positions[i] = (player.x, player.y)

        # Áp dụng di chuyển mới cho tất cả cùng lúc
        for i, player in enumerate(self.players):
            if player.alive:
                player.x, player.y = new_positions[i]

        # ── Item Contention Logic ──────────────────────────────────────
        # Sau khi TẤT CẢ agents đã di chuyển → kiểm tra ai bước vào ô item
        # Rule: ≥2 agents cùng bước vào cùng ô item trong cùng 1 step
        #       → item bị HỦY, không ai nhận (triệt tiêu)
        item_claimants = {}  # {(row,col): [agent_ids]}
        for i, player in enumerate(self.players):
            if not player.alive:
                continue
            cell = int(self.grid[player.x, player.y])
            if cell in (ITEM_RAD, ITEM_CAP):
                pos = (player.x, player.y)
                item_claimants.setdefault(pos, []).append(i)

        for pos, claimants in item_claimants.items():
            cell = int(self.grid[pos[0], pos[1]])
            if len(claimants) == 1:
                # Chỉ 1 agent → nhận item bình thường
                pid    = claimants[0]
                player = self.players[pid]
                got_item = False
                if cell == ITEM_RAD and player.bomb_radius_bonus < MAX_RADIUS - 1:
                    player.bomb_radius_bonus += 1
                    got_item = True
                elif cell == ITEM_CAP and player.bombs_left < MAX_CAPACITY:
                    # Tăng capacity: thêm 1 vào bombs_left (đơn giản hóa)
                    player.bombs_left  += 1
                    player.max_capacity = min(player.max_capacity + 1, MAX_CAPACITY)
                    got_item = True

                if got_item:
                    rewards[pid] += RewardConfig.ITEM_PICKUP
                    info["items_got"][pid] += 1
                    player.items_collected += 1
                # Xóa item khỏi bản đồ dù nhận được hay không (đã MAX)
                self.grid[pos[0], pos[1]] = GRASS

            else:
                # ≥2 agents tranh giành → item bị HỦY
                # KHÔNG ai nhận; phạt tất cả agents tham gia tranh giành
                self.grid[pos[0], pos[1]] = GRASS
                for pid in claimants:
                    rewards[pid] += RewardConfig.ITEM_CONTENTION
                    info["item_contention"][pid] += 1

        # ── Bước 3: Place Bombs (conflict resolution) ─────────────────
        # Engine xử lý theo thứ tự agent ID 0→3
        # Nếu 2+ agents đặt bom cùng ô:
        #   - Radius lớn hơn → thắng
        #   - Radius bằng nhau → agent ID nhỏ hơn giữ (xử lý trước)
        #   - Chỉ owner bom giữ được mới bị trừ bombs_left
        pending_bombs = {}   # {(x,y): BombData}

        for i in range(4):   # Thứ tự ID 0→3 như engine BTC
            player = self.players[i]
            if not player.alive or int(actions[i]) != ACTION_BOMB:
                continue
            if player.bombs_left <= 0:
                continue
            px, py = player.x, player.y
            # Không đặt nếu ô đã có bom từ bước trước
            if (px, py) in bomb_positions_before:
                continue

            new_radius = player.radius
            new_bomb   = BombData(px, py, i, new_radius)

            if (px, py) in pending_bombs:
                existing = pending_bombs[(px, py)]
                if new_radius > existing.radius:
                    # Bom mới thắng: hoàn trả bombs_left cho owner cũ
                    self.players[existing.owner_id].bombs_left += 1
                    pending_bombs[(px, py)] = new_bomb
                    player.bombs_left  -= 1
                    player.bombs_placed += 1
                    info["bombs_placed"][i] += 1
                # else: bom cũ thắng, agent mới KHÔNG bị trừ bombs_left
            else:
                pending_bombs[(px, py)] = new_bomb
                player.bombs_left  -= 1
                player.bombs_placed += 1
                info["bombs_placed"][i] += 1

        self.bombs.extend(pending_bombs.values())

        # ── Bước 4: Decrease Bomb Timers ──────────────────────────────
        for b in self.bombs:
            b.timer -= 1

        # ── Bước 5: Resolve Explosions (Chain Reaction) ───────────────
        # Tất cả bom có timer ≤ 0 nổ đồng loạt;
        # Nếu sóng nổ chạm bom khác → bom đó nổ ngay trong cùng step (chain reaction)
        to_explode = [b for b in self.bombs if b.timer <= 0]
        self.bombs  = [b for b in self.bombs if b.timer > 0]

        # Dùng set để tránh chain loop vô hạn
        exploded_ids = set()
        explode_queue = list(to_explode)

        all_blast_tiles  = set()    # Toàn bộ ô bị ảnh hưởng step này
        boxes_destroyed  = set()    # Ô box bị phá

        while explode_queue:
            bomb = explode_queue.pop(0)
            bid  = id(bomb)
            if bid in exploded_ids:
                continue
            exploded_ids.add(bid)

            bx, by = bomb.x, bomb.y
            br     = bomb.radius

            # Tính blast tiles
            blast = {(bx, by)}
            for dx, dy in ((-1, 0), (+1, 0), (0, -1), (0, +1)):
                for r in range(1, br + 1):
                    nx, ny = bx + dx * r, by + dy * r
                    if not (0 <= nx < GRID_SIZE and 0 <= ny < GRID_SIZE): break
                    cell = int(self.grid[nx, ny])
                    if cell == WALL: break
                    blast.add((nx, ny))
                    if cell == BOX:
                        boxes_destroyed.add((nx, ny))
                        break

            all_blast_tiles |= blast

            # Chain reaction: bom còn sống bị dính sóng nổ → nổ ngay
            still_alive_bombs = []
            for other_b in self.bombs:
                if (other_b.x, other_b.y) in blast and id(other_b) not in exploded_ids:
                    explode_queue.append(other_b)
                else:
                    still_alive_bombs.append(other_b)
            self.bombs = still_alive_bombs

            # Hoàn trả bombs_left cho owner (bom vừa nổ)
            if 0 <= bomb.owner_id < 4:
                self.players[bomb.owner_id].bombs_left += 1

        # Xử lý box bị phá
        for (bx, by) in boxes_destroyed:
            if int(self.grid[bx, by]) == BOX:    # Chưa bị phá bởi chain
                self.grid[bx, by] = GRASS
                # Tìm owner của bom gây ra (đơn giản: owner bom đầu tiên nổ ô đó)
                # Trong thực tế khó xác định khi chain reaction → gán cho explosion chung
                # Để đơn giản: reward boxes cho tất cả owners có bomb tham gia
                # (Có thể tinh chỉnh sau)

                # Drop item (30% radius, 30% capacity, 40% nothing)
                roll = self.rng.random()
                if roll < 0.30:
                    self.grid[bx, by] = ITEM_RAD
                elif roll < 0.60:
                    self.grid[bx, by] = ITEM_CAP

        # Tính reward boxes_broken (gán cho owner bom đầu tiên đã nổ — simplified)
        # Lưu owner từ danh sách to_explode ban đầu
        for b in to_explode:
            oid = b.owner_id
            if not (0 <= oid < 4): continue
            bx, by = b.x, b.y
            br = b.radius
            for dx, dy in ((-1, 0), (+1, 0), (0, -1), (0, +1)):
                for r in range(1, br + 1):
                    nx, ny = bx + dx * r, by + dy * r
                    if not (0 <= nx < GRID_SIZE and 0 <= ny < GRID_SIZE): break
                    if int(self.grid[nx, ny]) == WALL: break
                    if (nx, ny) in boxes_destroyed:
                        self.players[oid].boxes_broken += 1
                        info["boxes_broken"][oid] += 1
                        rewards[oid] += RewardConfig.BOX_BROKEN
                        boxes_destroyed.discard((nx, ny))   # Chỉ tính 1 lần
                        break

        # ── Bước 6: Remove dead agents ────────────────────────────────
        prev_alive = [p.alive for p in self.players]
        for i, player in enumerate(self.players):
            if player.alive and (player.x, player.y) in all_blast_tiles:
                player.alive = False
                info["dead_this_step"].append(i)
                rewards[i] += RewardConfig.DEATH

        # Kill reward: nếu agent i chết do bom của owner o → o được kill reward
        # (Dùng thông tin to_explode để biết bomb → owner)
        for b in to_explode:
            oid = b.owner_id
            if not (0 <= oid < 4): continue
            bx, by = b.x, b.y
            br = b.radius
            # Tính blast lại (nhỏ gọn)
            blast = {(bx, by)}
            for dx, dy in ((-1, 0), (+1, 0), (0, -1), (0, +1)):
                for r in range(1, br + 1):
                    nx, ny = bx + dx * r, by + dy * r
                    if not (0 <= nx < GRID_SIZE and 0 <= ny < GRID_SIZE): break
                    if int(self.grid[nx, ny]) == WALL: break
                    blast.add((nx, ny))
                    if int(self.grid[nx, ny]) == BOX: break
            for i, (was_alive, player) in enumerate(zip(prev_alive, self.players)):
                if was_alive and not player.alive and i != oid:
                    if (player.x, player.y) in blast:
                        rewards[oid] += RewardConfig.KILL
                        self.players[oid].kills += 1
                        info["kills"][oid] += 1

        # ── Bước 7: Auto-spawn Items ───────────────────────────────────
        # P = 0.0003 × (current_step / 165) — tăng dần theo thời gian
        # Chỉ spawn trên ô cỏ trống (không có agent)
        spawn_prob = 0.0003 * (self.current_step / 165.0)
        agent_positions = {(p.x, p.y) for p in self.players if p.alive}
        for r in range(1, 12):
            for c in range(1, 12):
                if (int(self.grid[r, c]) == GRASS
                        and (r, c) not in agent_positions):
                    if self.rng.random() < spawn_prob:
                        self.grid[r, c] = (
                            ITEM_RAD if self.rng.random() < 0.5 else ITEM_CAP
                        )

        # ── Survive reward ─────────────────────────────────────────────
        for i, player in enumerate(self.players):
            if player.alive:
                rewards[i] += RewardConfig.SURVIVE_STEP

        # ── Bước 8: Check End Conditions ──────────────────────────────
        alive_count = sum(1 for p in self.players if p.alive)
        done = (alive_count <= 1) or (self.current_step >= 500)

        if done:
            terminal = self._calculate_terminal_rewards()
            for i in range(4):
                rewards[i] += terminal[i]

        return self._get_obs(), rewards, done, info

    def _can_move_to(self, x: int, y: int, bomb_positions: set) -> bool:
        """Kiểm tra agent có thể di chuyển vào ô (x,y) không."""
        if not (0 <= x < GRID_SIZE and 0 <= y < GRID_SIZE):
            return False
        cell = int(self.grid[x, y])
        if cell in (WALL, BOX):
            return False
        # Bom đang nằm trên sàn từ bước trước chặn di chuyển
        if (x, y) in bomb_positions:
            return False
        return True

    def _calculate_terminal_rewards(self) -> list:
        """Phần thưởng cuối game (thắng/thua/tiebreaker)."""
        rewards = [0.0] * 4
        alive   = [p for p in self.players if p.alive]

        if len(alive) == 1:
            # Thắng outright — winner nhận WIN reward
            rewards[alive[0].id] = RewardConfig.WIN
        elif len(alive) == 0:
            pass  # Tất cả chết → không ai thắng
        else:
            # Step 500 — tiebreaker
            ranks = calculate_tiebreaker_winner(self.players)
            for pid, rank in ranks.items():
                if rank == 1:
                    rewards[pid] = RewardConfig.WIN
                elif rank == 2:
                    rewards[pid] = RewardConfig.TIE_LOSS
                else:
                    rewards[pid] = RewardConfig.TIE_LOSS * 1.5

        return rewards


# ============================================================
# SECTION C: TIEBREAKER CALCULATOR
# ============================================================

def calculate_tiebreaker_winner(players: list) -> dict:
    """
    Tính thứ hạng khi ≥2 agents còn sống sau step 500.
    Thứ tự ưu tiên: Kills > Boxes Broken > Items Collected > Bombs Placed

    Returns:
        dict {agent_id: rank} — rank 1 = nhất, rank N = bét
    """
    alive = [
        (p.kills, p.boxes_broken, p.items_collected, p.bombs_placed, p.id)
        for p in players if p.alive
    ]
    # Sắp xếp giảm dần theo tất cả tiêu chí
    alive_sorted = sorted(alive, reverse=True)

    result = {}
    for rank, (*_, pid) in enumerate(alive_sorted, start=1):
        result[pid] = rank

    # Agents đã chết → xếp sau tất cả agents sống
    dead_rank = len(alive) + 1
    for p in players:
        if not p.alive:
            result[p.id] = dead_rank

    return result


# ============================================================
# SECTION D: REWARD CONFIG
# ============================================================

class RewardConfig:
    """Cấu hình reward shaping."""
    WIN             = +1000.0    # Thắng outright hoặc tiebreaker rank 1
    DEATH           = -1000.0    # Bị loại
    TIE_LOSS        = -200.0     # Thua tiebreaker (rank 2 ở step 500)
    SURVIVE_STEP    = +0.1       # Sống sót qua mỗi step
    BOX_BROKEN      = +10.0      # Phá được 1 hộp
    ITEM_PICKUP     = +30.0      # Nhặt được item (khi chưa MAX)
    ITEM_CONTENTION = -15.0      # Tranh giành item vô ích
    KILL            = +500.0     # Giết địch
    DEADEND_PENALTY = -20.0      # Đi vào ngõ cụt (chưa dùng ở GameEnv, để Actor học)
    BOMB_SPAM       = -5.0       # Spam bom không trúng (chỉ áp dụng step ≤ 450)


# ============================================================
# SECTION E: BASELINE AGENTS (Opponents for training)
# ============================================================

class RandomAgent:
    """Agent ngẫu nhiên — opponent yếu nhất cho giai đoạn early training."""

    def __init__(self, agent_id: int):
        self.agent_id = int(agent_id)
        self._masker  = AlphaBetaMasker()

    def act(self, obs: dict) -> int:
        state  = GameState(obs["map"], obs["players"], obs["bombs"], self.agent_id)
        legal  = state.get_legal_actions(self.agent_id)
        return random.choice(legal) if legal else ACTION_STOP


def load_baseline_agent(agent_type: str, agent_id: int):
    """
    Load baseline agent theo tên.
    Thứ tự ưu tiên: engine baselines → fallback RandomAgent.
    """
    type_lower = agent_type.lower()
    agent_dir  = Path(__file__).parent / "Bomberland-GDGoC-AI-Challenge-main" \
                 / "Bomberland-GDGoC-AI-Challenge-main"

    if type_lower == "random":
        return RandomAgent(agent_id)

    try:
        sys.path.insert(0, str(agent_dir))
        if type_lower == "simple":
            from agent.simple_rule_agent import Agent as A
        elif type_lower == "tactical":
            from agent.tactical_rule_agent import Agent as A
        elif type_lower == "smarter":
            from agent.smarter_rule_agent import Agent as A
        elif type_lower == "genius":
            from agent.genius_rule_agent import Agent as A
        else:
            return RandomAgent(agent_id)
        return A(agent_id)
    except (ImportError, Exception):
        return RandomAgent(agent_id)


def make_checkpoint_agent(net_state: dict, device, agent_id: int,
                           masker: AlphaBetaMasker):
    """Tạo agent dùng checkpoint weights cũ (self-play opponent)."""

    class _CheckpointAgent:
        def __init__(self):
            self.agent_id = agent_id
            self._net = ActorCriticNet()
            self._net.load_state_dict(net_state)
            self._net.to(device)
            self._net.eval()
            self._masker = masker
            self._device = device

        def act(self, obs: dict) -> int:
            state = GameState(obs["map"], obs["players"], obs["bombs"], self.agent_id)
            mask  = self._masker.get_safe_mask(state, self.agent_id, time_budget_ms=25)
            mf, af = encode_obs(obs, self.agent_id)
            mt = torch.FloatTensor(mf).unsqueeze(0).to(self._device)
            at = torch.FloatTensor(af).unsqueeze(0).to(self._device)
            with torch.no_grad():
                logits, _ = self._net(mt, at)
            logits_np = logits.squeeze(0).cpu().numpy()
            for i, safe in enumerate(mask):
                if not safe:
                    logits_np[i] = -1e9
            return int(np.argmax(logits_np))

    return _CheckpointAgent()


# ============================================================
# SECTION F: ROLLOUT BUFFER & GAE
# ============================================================

class RolloutBuffer:
    """Buffer lưu rollout data cho PPO update."""

    def __init__(self):
        self.map_states  = []
        self.aux_states  = []
        self.actions     = []
        self.log_probs   = []
        self.rewards     = []
        self.dones       = []
        self.values      = []
        self.masks       = []

    def add(self, map_s, aux_s, action, log_prob, reward, done, value, mask):
        self.map_states.append(map_s)
        self.aux_states.append(aux_s)
        self.actions.append(action)
        self.log_probs.append(log_prob)
        self.rewards.append(reward)
        self.dones.append(done)
        self.values.append(value)
        self.masks.append(mask)

    def __len__(self):
        return len(self.actions)

    def to_tensors(self, device):
        map_t  = torch.FloatTensor(np.stack(self.map_states)).to(device)
        aux_t  = torch.FloatTensor(np.stack(self.aux_states)).to(device)
        act_t  = torch.LongTensor(self.actions).to(device)
        logp_t = torch.FloatTensor(self.log_probs).to(device)
        rew_t  = torch.FloatTensor(self.rewards).to(device)
        done_t = torch.FloatTensor(self.dones).to(device)
        val_t  = torch.FloatTensor(self.values).to(device)
        mask_t = torch.BoolTensor(np.array(self.masks)).to(device)
        return map_t, aux_t, act_t, logp_t, rew_t, done_t, val_t, mask_t


def compute_gae(rewards: list, values: list, dones: list,
                gamma: float = 0.99, lam: float = 0.95) -> tuple:
    """
    Compute Generalized Advantage Estimation (GAE).
    GAE giảm phương sai estimate advantage, ổn định PPO training.
    """
    advantages = []
    gae        = 0.0
    next_value = 0.0

    for r, v, d in zip(reversed(rewards), reversed(values), reversed(dones)):
        delta = r + gamma * next_value * (1.0 - d) - v
        gae   = delta + gamma * lam * (1.0 - d) * gae
        advantages.insert(0, gae)
        next_value = v

    returns = [a + v for a, v in zip(advantages, values)]
    return advantages, returns


# ============================================================
# SECTION G: PPO TRAINER
# ============================================================

class PPOTrainer:
    """
    PPO Trainer với Hybrid Opponent Strategy:
      Episode 0-2000:  50% Baseline + 50% Self-play checkpoint
      Episode 2001+:   40% Baseline + 60% Self-play checkpoint (tăng self-play)

    Action Masking trong PPO:
      Logits của actions bị mask được set -inf TRƯỚC softmax
      → gradient không lan vào actions nguy hiểm
    """

    def __init__(self, net: ActorCriticNet, device,
                 lr: float = 3e-4,
                 clip_eps: float = 0.2,
                 entropy_coeff: float = 0.01,
                 value_coeff: float = 0.5,
                 gamma: float = 0.99,
                 gae_lambda: float = 0.95,
                 ppo_epochs: int = 4,
                 mini_batch_size: int = 128,
                 rollout_steps: int = 2048,
                 max_grad_norm: float = 0.5):

        self.net             = net
        self.device          = device
        self.clip_eps        = clip_eps
        self.entropy_coeff   = entropy_coeff
        self.value_coeff     = value_coeff
        self.gamma           = gamma
        self.gae_lambda      = gae_lambda
        self.ppo_epochs      = ppo_epochs
        self.mini_batch_size = mini_batch_size
        self.rollout_steps   = rollout_steps
        self.max_grad_norm   = max_grad_norm

        self.optimizer = optim.Adam(net.parameters(), lr=lr, eps=1e-5)
        self.masker    = AlphaBetaMasker()

        # Checkpoint pool giữ 5 versions tốt nhất
        self.checkpoint_pool: list = []
        self.MAX_POOL_SIZE          = 5

        # Tracking
        self.total_episodes = 0
        self.total_steps    = 0

    def save_checkpoint(self):
        """Lưu snapshot weights hiện tại vào pool."""
        snapshot = deepcopy(self.net.state_dict())
        self.checkpoint_pool.append(snapshot)
        if len(self.checkpoint_pool) > self.MAX_POOL_SIZE:
            self.checkpoint_pool.pop(0)

    def _make_opponent(self, agent_id: int, episode: int,
                       baseline_types: list):
        """
        Tạo opponent theo hybrid strategy.
        episode < 2000: 50% baseline, 50% checkpoint
        episode ≥ 2000: 40% baseline, 60% checkpoint
        """
        baseline_prob = 0.5 if episode < 2000 else 0.4
        use_baseline  = (random.random() < baseline_prob
                         or not self.checkpoint_pool)

        if use_baseline:
            btype = random.choice(baseline_types)
            return load_baseline_agent(btype, agent_id)
        else:
            old_state = random.choice(self.checkpoint_pool)
            return make_checkpoint_agent(old_state, self.device,
                                         agent_id, self.masker)

    def collect_rollout(self, env: GameEnv, my_id: int,
                        episode: int, baseline_types: list) -> RolloutBuffer:
        """
        Thu thập rollout_steps bước data từ môi trường.
        Opponents được tạo mới mỗi episode kết thúc.

        QUAN TRỌNG: Phải switch net sang eval() trước khi collect.
        Lý do: BatchNorm2d ở training mode với batch_size=1 tính unbiased
        variance = (x - mean)^2 / (N-1) = 0/0 = NaN → probs toàn NaN
        → torch.distributions.Categorical crash với ValueError Simplex().
        """
        buffer   = RolloutBuffer()
        obs      = env.reset()
        opponents = {
            i: self._make_opponent(i, episode, baseline_types)
            for i in range(4) if i != my_id
        }
        steps_collected  = 0
        eps_this_rollout = 0

        # ── FIX: Switch to eval mode for single-sample inference ──────
        # BatchNorm2d với batch=1 ở train mode → NaN. eval() dùng
        # running statistics đã tích lũy → ổn định.
        self.net.eval()

        while steps_collected < self.rollout_steps:
            # Encode my obs
            map_feat, aux_feat = encode_obs(obs, my_id)
            state = GameState(obs["map"], obs["players"], obs["bombs"], my_id)

            # Compute safe mask
            mask = self.masker.get_safe_mask(state, my_id, time_budget_ms=20)

            map_t = torch.FloatTensor(map_feat).unsqueeze(0).to(self.device)
            aux_t = torch.FloatTensor(aux_feat).unsqueeze(0).to(self.device)

            with torch.no_grad():
                logits, value = self.net(map_t, aux_t)
                logits_np = logits.squeeze(0).cpu().numpy().copy()

            # ── FIX: NaN guard — nếu network vẫn cho NaN (training
            # instability sau update) thì fallback về uniform logits
            if np.any(np.isnan(logits_np)) or np.any(np.isinf(logits_np)):
                logits_np = np.zeros(6, dtype=np.float32)

            # Apply mask TRƯỚC khi lấy xác suất
            for i, safe in enumerate(mask):
                if not safe:
                    logits_np[i] = -1e9

            # Đảm bảo ít nhất 1 action hợp lệ (không bị mask all)
            if np.all(logits_np <= -1e8):
                logits_np[ACTION_STOP] = 0.0

            mlogits  = torch.FloatTensor(logits_np).to(self.device)
            probs    = torch.softmax(mlogits, dim=-1)

            # ── FIX: Clamp probs để tránh Categorical(Simplex) fail
            # khi có floating-point rounding error dẫn đến sum != 1
            probs    = probs.clamp(min=1e-8)
            probs    = probs / probs.sum()

            dist     = torch.distributions.Categorical(probs)
            action_t = dist.sample()
            log_prob = dist.log_prob(action_t).item()
            action   = action_t.item()
            val      = value.squeeze().item()

            # Opponent actions
            all_actions = [ACTION_STOP] * 4
            all_actions[my_id] = action
            for opp_id, opp in opponents.items():
                try:
                    all_actions[opp_id] = opp.act(obs)
                except Exception:
                    all_actions[opp_id] = ACTION_STOP

            next_obs, rewards, done, info = env.step(all_actions)
            reward = float(rewards[my_id])

            # Chỉ lưu bước này nếu log_prob hợp lệ
            if not (np.isnan(log_prob) or np.isinf(log_prob)):
                buffer.add(map_feat, aux_feat, action, log_prob,
                           reward, float(done), val, mask)
                steps_collected += 1

            obs = next_obs

            if done:
                eps_this_rollout += 1
                self.total_episodes += 1
                obs = env.reset()
                opponents = {
                    i: self._make_opponent(i, episode + eps_this_rollout, baseline_types)
                    for i in range(4) if i != my_id
                }

        # ── Switch lại train mode trước khi trả về để update() hoạt động
        self.net.train()
        self.total_steps += steps_collected
        return buffer

    def update(self, buffer: RolloutBuffer) -> dict:
        """
        Chạy PPO update từ collected buffer.
        Returns metrics dict.
        BatchNorm cần train mode ở đây (mini_batch_size >= 4 là đủ).
        """
        self.net.train()  # Đảm bảo train mode cho BatchNorm
        (map_t, aux_t, act_t, old_logp_t,
         rew_t, done_t, val_t, mask_t) = buffer.to_tensors(self.device)

        # Compute GAE
        adv_list, ret_list = compute_gae(
            buffer.rewards, buffer.values, buffer.dones,
            self.gamma, self.gae_lambda
        )
        adv_t = torch.FloatTensor(adv_list).to(self.device)
        ret_t = torch.FloatTensor(ret_list).to(self.device)

        # Normalize advantages
        adv_t = (adv_t - adv_t.mean()) / (adv_t.std() + 1e-8)

        n = len(buffer)
        metrics = {"policy_loss": 0.0, "value_loss": 0.0, "entropy": 0.0}
        n_updates = 0

        for _ in range(self.ppo_epochs):
            indices = torch.randperm(n, device=self.device)
            for start in range(0, n, self.mini_batch_size):
                idx = indices[start: start + self.mini_batch_size]
                if len(idx) < 4:
                    continue

                mb_map  = map_t[idx]
                mb_aux  = aux_t[idx]
                mb_act  = act_t[idx]
                mb_olp  = old_logp_t[idx]
                mb_adv  = adv_t[idx]
                mb_ret  = ret_t[idx]
                mb_mask = mask_t[idx]   # (B, 6) bool

                # Forward
                logits, values = self.net(mb_map, mb_aux)

                # Apply action mask TRƯỚC softmax (gradient-safe)
                # Actions bị mask → -1e9 (tránh -inf để gradient không bị NaN)
                logits_m = logits.clone()
                logits_m[~mb_mask] = -1e9
                log_probs_all = F.log_softmax(logits_m, dim=-1)
                log_probs     = log_probs_all.gather(1, mb_act.unsqueeze(1)).squeeze(1)

                # Entropy (khuyến khích khám phá)
                probs   = torch.softmax(logits_m, dim=-1)
                entropy = -(probs * log_probs_all).sum(dim=-1).mean()

                # PPO clipped objective
                ratio = torch.exp(log_probs - mb_olp)
                surr1 = ratio * mb_adv
                surr2 = torch.clamp(ratio,
                                    1.0 - self.clip_eps,
                                    1.0 + self.clip_eps) * mb_adv
                policy_loss = -torch.min(surr1, surr2).mean()

                # Value loss
                value_loss = F.mse_loss(values.squeeze(1), mb_ret)

                # Total loss
                loss = (policy_loss
                        + self.value_coeff  * value_loss
                        - self.entropy_coeff * entropy)

                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.net.parameters(), self.max_grad_norm)
                self.optimizer.step()

                metrics["policy_loss"] += policy_loss.item()
                metrics["value_loss"]  += value_loss.item()
                metrics["entropy"]     += entropy.item()
                n_updates += 1

        if n_updates > 0:
            for k in metrics:
                metrics[k] /= n_updates
        return metrics


# ============================================================
# SECTION H: IMITATION LEARNING
# ============================================================

def collect_il_demonstrations(env: GameEnv, teacher_id: int,
                               n_episodes: int, save_path: str,
                               baseline_types: list = None) -> list:
    """
    Chạy Agent hiện tại (Alpha-Beta Masker + random policy) làm teacher
    để thu thập demonstration data.

    Vì weights chưa có trong phase này, teacher thực ra là:
      AlphaBetaMasker → chọn action safe → random trong safe actions

    Output: list of (map_feat, aux_feat, action) tuples
    """
    if baseline_types is None:
        baseline_types = ["random", "simple"]

    masker = AlphaBetaMasker()
    demos  = []

    print(f"[IL Collect] {n_episodes} episodes, teacher_id={teacher_id}")
    for ep in range(n_episodes):
        obs  = env.reset()
        done = False
        ep_steps = 0

        opponents = {
            i: load_baseline_agent(random.choice(baseline_types), i)
            for i in range(4) if i != teacher_id
        }

        while not done and ep_steps < 500:
            # Teacher action: Alpha-Beta Masker + greedy heuristic
            state = GameState(obs["map"], obs["players"], obs["bombs"], teacher_id)
            mask  = masker.get_safe_mask(state, teacher_id, time_budget_ms=30)
            safe_actions = [a for a in range(6) if mask[a]]

            if not safe_actions:
                teacher_action = ACTION_STOP
            else:
                # Heuristic: ưu tiên BOMB nếu safe, rồi move về item/enemy
                if ACTION_BOMB in safe_actions:
                    # Kiểm tra xem đặt bom có trúng box/enemy không
                    me = state.players[teacher_id]
                    radius = 1 + me[4]
                    boxes_hit = 0
                    for dx, dy in ((-1,0),(+1,0),(0,-1),(0,+1)):
                        for r in range(1, radius+1):
                            nx, ny = me[0]+dx*r, me[1]+dy*r
                            if not state._in_bounds(nx, ny): break
                            if int(state.grid[nx,ny]) == WALL: break
                            if int(state.grid[nx,ny]) == BOX:
                                boxes_hit += 1; break
                    if boxes_hit > 0:
                        teacher_action = ACTION_BOMB
                    else:
                        teacher_action = random.choice(
                            [a for a in safe_actions if a != ACTION_BOMB] or safe_actions
                        )
                else:
                    teacher_action = random.choice(safe_actions)

            # Ghi nhận demonstration
            map_feat, aux_feat = encode_obs(obs, teacher_id)
            demos.append((map_feat, aux_feat, teacher_action))

            # Collect all actions
            all_actions = [ACTION_STOP] * 4
            all_actions[teacher_id] = teacher_action
            for oid, opp in opponents.items():
                try:
                    all_actions[oid] = opp.act(obs)
                except Exception:
                    all_actions[oid] = ACTION_STOP

            obs, _, done, _ = env.step(all_actions)
            ep_steps += 1

        if (ep + 1) % 200 == 0:
            print(f"[IL Collect] Ep {ep+1}/{n_episodes}, demos: {len(demos)}")

    with open(save_path, "wb") as f:
        pickle.dump(demos, f)
    print(f"[IL Collect] Saved {len(demos)} demos → {save_path}")
    return demos


def train_il(demos_path: str, save_path: str, device,
             epochs: int = 10, batch_size: int = 512, lr: float = 1e-3) -> ActorCriticNet:
    """
    Train ActorCriticNet bằng Imitation Learning (Supervised Cross-Entropy trên Actor).
    Critic không được train trong phase này (không có labels).
    """
    print(f"[IL Train] Loading from {demos_path}...")
    with open(demos_path, "rb") as f:
        demos = pickle.load(f)

    n = len(demos)
    print(f"[IL Train] {n} samples, {epochs} epochs, batch={batch_size}")

    map_data = np.stack([d[0] for d in demos]).astype(np.float32)
    aux_data = np.stack([d[1] for d in demos]).astype(np.float32)
    act_data = np.array([d[2] for d in demos], dtype=np.int64)

    net       = ActorCriticNet().to(device)
    optimizer = optim.Adam(net.parameters(), lr=lr)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

    for epoch in range(epochs):
        idx     = np.random.permutation(n)
        tot_loss, correct, n_batches = 0.0, 0, 0

        for start in range(0, n, batch_size):
            b_idx = idx[start: start + batch_size]
            map_t = torch.FloatTensor(map_data[b_idx]).to(device)
            aux_t = torch.FloatTensor(aux_data[b_idx]).to(device)
            act_t = torch.LongTensor(act_data[b_idx]).to(device)

            logits, _ = net(map_t, aux_t)
            loss = F.cross_entropy(logits, act_t)

            optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(net.parameters(), 0.5)
            optimizer.step()

            tot_loss += loss.item()
            correct  += (logits.argmax(1) == act_t).sum().item()
            n_batches += 1

        scheduler.step()
        acc = correct / n * 100
        print(f"[IL Train] Epoch {epoch+1}/{epochs}: "
              f"loss={tot_loss/n_batches:.4f}, acc={acc:.1f}%")

    torch.save(net.state_dict(), save_path)
    print(f"[IL Train] Weights saved → {save_path}")
    return net


# ============================================================
# SECTION I: PPO TRAINING LOOP
# ============================================================

def train_ppo(load_path: str, save_path: str, device,
              n_rollouts: int = 200,
              checkpoint_interval: int = 20,
              baseline_types: list = None,
              my_agent_id: int = 0,
              rollout_steps: int = 2048) -> None:
    """
    PPO Fine-tuning với Hybrid Opponent.
    n_rollouts: số lần collect+update (mỗi rollout = rollout_steps steps).
    """
    if baseline_types is None:
        baseline_types = ["random", "simple", "tactical"]

    net = ActorCriticNet().to(device)
    if load_path and Path(load_path).exists():
        net.load_state_dict(
            torch.load(load_path, map_location=device, weights_only=True)
        )
        print(f"[PPO] Loaded weights from {load_path}")
    else:
        print("[PPO] Training from scratch (no weights loaded)")

    trainer = PPOTrainer(net, device, rollout_steps=rollout_steps)
    env     = GameEnv()
    episode_counter = 0

    print(f"[PPO] {n_rollouts} rollouts × {rollout_steps} steps, agent_id={my_agent_id}")

    for rollout_idx in range(n_rollouts):
        buffer  = trainer.collect_rollout(env, my_agent_id,
                                          episode_counter, baseline_types)
        metrics = trainer.update(buffer)
        episode_counter = trainer.total_episodes

        print(f"[PPO] Rollout {rollout_idx+1}/{n_rollouts} | "
              f"ep={episode_counter} | steps={trainer.total_steps} | "
              f"pl={metrics['policy_loss']:.4f} | "
              f"vl={metrics['value_loss']:.4f} | "
              f"ent={metrics['entropy']:.4f}")

        # Checkpoint
        if (rollout_idx + 1) % checkpoint_interval == 0:
            trainer.save_checkpoint()
            ckpt = save_path.replace(".pth", f"_ckpt{rollout_idx+1}.pth")
            torch.save(net.state_dict(), ckpt)
            print(f"[PPO] Checkpoint → {ckpt}")

    torch.save(net.state_dict(), save_path)
    print(f"[PPO] Final weights → {save_path}")


# ============================================================
# SECTION J: BENCHMARK
# ============================================================

def run_benchmark(weights_path: str, device, n_episodes: int = 100,
                  opponent_type: str = "tactical") -> float:
    """Đánh giá win rate của agent vs một loại baseline."""
    from agent import Agent as SubmissionAgent

    agent = SubmissionAgent(0)
    if weights_path and Path(weights_path).exists():
        agent.net.load_state_dict(
            torch.load(weights_path, map_location=device, weights_only=True)
        )
        agent.net.eval()

    env      = GameEnv()
    wins     = 0

    for ep in range(n_episodes):
        obs  = env.reset()
        done = False
        opponents = {
            i: load_baseline_agent(opponent_type, i)
            for i in range(1, 4)
        }
        final_rewards = [0.0] * 4

        while not done:
            all_actions = [ACTION_STOP] * 4
            all_actions[0] = agent.act(obs)
            for oid, opp in opponents.items():
                try:
                    all_actions[oid] = opp.act(obs)
                except Exception:
                    all_actions[oid] = ACTION_STOP
            obs, rewards, done, _ = env.step(all_actions)
            for i in range(4):
                final_rewards[i] += rewards[i]

        if final_rewards[0] == max(final_rewards):
            wins += 1

        if (ep + 1) % 20 == 0:
            print(f"[Benchmark] {ep+1}/{n_episodes}: win_rate={wins/(ep+1)*100:.1f}%")

    rate = wins / n_episodes
    print(f"[Benchmark] Final vs {opponent_type}: {wins}/{n_episodes} = {rate*100:.1f}%")
    return rate


# ============================================================
# SECTION K: MAIN CLI
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Bomberland Guided RL — Training Pipeline"
    )
    parser.add_argument(
        "--phase",
        choices=["il_collect", "il_train", "ppo", "benchmark"],
        required=True,
        help="Phase to run"
    )
    parser.add_argument("--episodes",   type=int,   default=5000,
                        help="Episodes (IL collect) or rollouts (PPO)")
    parser.add_argument("--rollout_steps", type=int, default=2048,
                        help="Steps per PPO rollout")
    parser.add_argument("--output",     type=str,   default="weights.pth")
    parser.add_argument("--load",       type=str,   default=None,
                        help="Path to weights to load")
    parser.add_argument("--demos",      type=str,   default="demos.pkl",
                        help="Path to demonstrations file")
    parser.add_argument("--agent_id",   type=int,   default=0,
                        help="Our agent ID (0-3)")
    parser.add_argument("--checkpoint_interval", type=int, default=20,
                        help="Save checkpoint every N rollouts")
    parser.add_argument("--baseline_types", nargs="+",
                        default=["random", "simple", "tactical"],
                        help="Baseline types for opponents")
    parser.add_argument("--opponent",   type=str,   default="tactical",
                        help="Opponent for benchmark")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[Main] Device: {device}")

    if args.phase == "il_collect":
        env = GameEnv()
        collect_il_demonstrations(
            env=env,
            teacher_id=args.agent_id,
            n_episodes=args.episodes,
            save_path=args.demos,
            baseline_types=args.baseline_types,
        )

    elif args.phase == "il_train":
        train_il(
            demos_path=args.demos,
            save_path=args.output,
            device=device,
        )

    elif args.phase == "ppo":
        train_ppo(
            load_path=args.load,
            save_path=args.output,
            device=device,
            n_rollouts=args.episodes,
            checkpoint_interval=args.checkpoint_interval,
            baseline_types=args.baseline_types,
            my_agent_id=args.agent_id,
            rollout_steps=args.rollout_steps,
        )

    elif args.phase == "benchmark":
        run_benchmark(
            weights_path=args.load,
            device=device,
            n_episodes=args.episodes,
            opponent_type=args.opponent,
        )
